<?php
$output = shell_exec('php artisan storage:link');
echo $output;
?>
